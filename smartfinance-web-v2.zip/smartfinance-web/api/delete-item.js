import { pluggyFetch } from "../lib/pluggy.js";

export async function DELETE(request) {
  try {
    const url = new URL(request.url);
    const itemId = url.searchParams.get("itemId");
    if (!itemId) return Response.json({ error: "itemId é obrigatório" }, { status: 400 });

    await pluggyFetch(`/items/${itemId}`, { method: "DELETE" });
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
