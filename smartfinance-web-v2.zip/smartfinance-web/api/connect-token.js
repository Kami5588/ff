import { pluggyFetch } from "../lib/pluggy.js";

export async function GET() {
  try {
    const token = await pluggyFetch("/connect_token", {
      method: "POST",
      body: JSON.stringify({ options: { clientUserId: "smartfinance-web" } }),
    });
    return Response.json(token);
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
