import { pluggyFetch } from "../lib/pluggy.js";

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const itemId = url.searchParams.get("itemId");
    if (!itemId) return Response.json({ error: "itemId é obrigatório" }, { status: 400 });

    const item = await pluggyFetch(`/items/${itemId}`);
    return Response.json({
      itemId: item.id,
      bankName: item.connector ? item.connector.name : "Banco",
      connectorImageUrl: item.connector ? item.connector.imageUrl : null,
      status: item.status,
    });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
