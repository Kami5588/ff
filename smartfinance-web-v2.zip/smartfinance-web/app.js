const fmtMoney = (v) =>
  (v || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const fmtDate = (iso) => new Date(iso).toLocaleDateString("pt-BR");

const STORAGE_KEY = "sf_connections";
let categoryChart = null;

function getConnections() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}
function saveConnections(list) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

async function api(pathname, options) {
  const res = await fetch(pathname, options);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `Erro ${res.status}`);
  return json;
}

function showWarning(msg) {
  const el = document.getElementById("setup-warning");
  el.textContent = msg;
  el.classList.remove("hidden");
}
function clearWarning() {
  const el = document.getElementById("setup-warning");
  el.classList.add("hidden");
  el.textContent = "";
}

async function connectBank() {
  let tokenResp;
  try {
    tokenResp = await api("/api/connect-token");
  } catch (e) {
    showWarning(
      "Não foi possível gerar o token de conexão. Verifique se PLUGGY_CLIENT_ID e PLUGGY_CLIENT_SECRET estão configurados nas variáveis de ambiente do projeto na Vercel. Detalhe: " +
        e.message
    );
    return;
  }

  const pluggyConnect = new PluggyConnect({
    connectToken: tokenResp.accessToken,
    includeSandbox: false,
    onSuccess: async (itemData) => {
      const itemId = itemData.item.id;
      let info = { itemId, bankName: "Banco", status: itemData.item.status };
      try {
        info = await api(`/api/item?itemId=${encodeURIComponent(itemId)}`);
      } catch (e) {
        console.error(e);
      }
      const list = getConnections();
      const idx = list.findIndex((c) => c.itemId === itemId);
      const entry = {
        itemId,
        bankName: info.bankName,
        status: info.status,
        updatedAt: new Date().toISOString(),
      };
      if (idx === -1) list.push(entry);
      else list[idx] = entry;
      saveConnections(list);
      loadDashboard();
    },
    onError: (error) => {
      console.error("Erro no Pluggy Connect:", error);
    },
  });
  pluggyConnect.init();
}

async function removeConnection(itemId) {
  if (!confirm("Remover esta conexão bancária do painel?")) return;
  try {
    await api(`/api/delete-item?itemId=${encodeURIComponent(itemId)}`, { method: "DELETE" });
  } catch (e) {
    console.error(e);
  }
  const list = getConnections().filter((c) => c.itemId !== itemId);
  saveConnections(list);
  loadDashboard();
}

function renderAccounts(accounts) {
  const el = document.getElementById("accounts-list");
  el.innerHTML = "";
  if (!accounts.length) {
    el.innerHTML = '<div class="empty">Nenhuma conta conectada ainda.</div>';
    return;
  }
  for (const acc of accounts) {
    const div = document.createElement("div");
    div.className = "list-item";
    div.innerHTML = `
      <div class="meta">
        <span class="name">${acc.bankName} · ${acc.name}</span>
        <span class="sub">${acc.number || ""}</span>
      </div>
      <span class="value ${acc.type === "CREDIT" ? "amount-negative" : ""}">${fmtMoney(acc.balance)}</span>
    `;
    el.appendChild(div);
  }
}

function renderConnections(connections) {
  const el = document.getElementById("connections-list");
  el.innerHTML = "";
  document.getElementById("total-banks").textContent = connections.length;
  if (!connections.length) {
    el.innerHTML =
      '<div class="empty">Nenhum banco conectado. Clique em "Conectar banco" para começar.</div>';
    return;
  }
  for (const conn of connections) {
    const div = document.createElement("div");
    div.className = "list-item";
    div.innerHTML = `
      <div class="meta">
        <span class="name">${conn.bankName}</span>
        <span class="sub">Status: ${conn.status || "—"} · atualizado em ${fmtDate(conn.updatedAt)}</span>
      </div>
      <button class="btn-danger" data-item="${conn.itemId}">Remover</button>
    `;
    div.querySelector("button").addEventListener("click", () => removeConnection(conn.itemId));
    el.appendChild(div);
  }
}

function renderTransactions(transactions) {
  const tbody = document.getElementById("tx-body");
  tbody.innerHTML = "";
  if (!transactions.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty">Sem lançamentos no período.</td></tr>';
    return;
  }
  for (const t of transactions) {
    const tr = document.createElement("tr");
    const isCredit = t.type === "CREDIT";
    tr.innerHTML = `
      <td>${fmtDate(t.date)}</td>
      <td>${t.bankName}</td>
      <td>${t.description}</td>
      <td>${t.category}</td>
      <td class="right ${isCredit ? "amount-positive" : "amount-negative"}">${fmtMoney(t.amount)}</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderCategoryChart(transactions) {
  const byCategory = {};
  for (const t of transactions) {
    if (t.type !== "DEBIT") continue;
    byCategory[t.category] = (byCategory[t.category] || 0) + Math.abs(t.amount);
  }
  const labels = Object.keys(byCategory);
  const data = Object.values(byCategory);

  const ctx = document.getElementById("category-chart");
  if (categoryChart) categoryChart.destroy();
  if (!labels.length) return;

  categoryChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels,
      datasets: [
        {
          data,
          backgroundColor: [
            "#4f8cff", "#2ecc8f", "#ff5d6c", "#f0c419", "#a06cd5",
            "#00c2d1", "#ff9f43", "#7f8fa6", "#e84393", "#22a6b3",
          ],
        },
      ],
    },
    options: {
      plugins: { legend: { position: "right", labels: { color: "#e8eef3", boxWidth: 12, font: { size: 11 } } } },
    },
  });
}

async function loadDashboard() {
  clearWarning();
  const connections = getConnections();
  renderConnections(connections);

  if (!connections.length) {
    document.getElementById("total-balance").textContent = fmtMoney(0);
    document.getElementById("total-credit").textContent = fmtMoney(0);
    renderAccounts([]);
    renderTransactions([]);
    renderCategoryChart([]);
    return;
  }

  let data;
  try {
    data = await api("/api/dashboard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ connections }),
    });
  } catch (e) {
    showWarning("Erro ao carregar o painel: " + e.message);
    return;
  }

  document.getElementById("total-balance").textContent = fmtMoney(data.totalBalance);
  document.getElementById("total-credit").textContent = fmtMoney(data.totalCreditUsed);
  renderAccounts(data.accounts);
  renderTransactions(data.transactions);
  renderCategoryChart(data.transactions);

  if (data.errors && data.errors.length) {
    showWarning(data.errors.join(" | "));
  }
}

document.getElementById("btn-connect").addEventListener("click", connectBank);
loadDashboard();
