# SmartFinance Painel (versão site — Vercel)

Diferente da primeira versão (que rodava só no seu computador, em `localhost`), esta vira um
site de verdade, com endereço próprio, parecido com o `smartfinance.base44.app` que você já tinha.
Depois de publicado, você só abre o link — não precisa deixar nenhum terminal aberto.

## 1. Pré-requisito: Node.js instalado

Abra um terminal e rode `node -v`. Se der erro, instale a versão LTS em https://nodejs.org.

## 2. Publicar na Vercel (gratuito)

Dentro da pasta `smartfinance-web`, rode:

```bash
npx vercel
```

Na primeira vez, ele vai abrir o navegador pedindo para você criar uma conta ou logar na Vercel
(pode ser com GitHub, Google ou e-mail — é gratuito). Depois, no terminal, aceite as perguntas
com Enter (valores padrão servem). Ao final, ele te dá um link de "preview" — ainda não é o
definitivo, falta configurar as chaves da Pluggy.

## 3. Configurar as chaves da Pluggy no site publicado

1. Acesse https://vercel.com/dashboard e abra o projeto `smartfinance-web` que acabou de ser criado.
2. Vá em **Settings → Environment Variables**.
3. Adicione duas variáveis (marcando Production, Preview e Development):
   - `PLUGGY_CLIENT_ID`
   - `PLUGGY_CLIENT_SECRET`

   (essas chaves vêm do seu Application em dashboard.pluggy.ai — se ainda não criou, veja o
   passo a passo em https://www.pluggy.ai/meu-pluggy)

4. Volte ao terminal, na pasta do projeto, e rode novamente para aplicar as variáveis:

```bash
npx vercel --prod
```

Isso te dá a URL final e permanente do site (algo como `smartfinance-web-seunome.vercel.app`).

## 4. Conectar seus bancos

Abra o link do site. Clique em **"+ Conectar banco"**.

- Se você já conectou Inter e Sicredi no **meu.pluggy.ai**: no widget que abrir, procure o
  conector **"MeuPluggy"** e faça login com seu e-mail/senha de lá. Isso traz as contas que já
  estavam conectadas.
- Para o Banco do Brasil (ou qualquer banco novo): pode conectar direto no widget, sem precisar
  passar pelo Meu Pluggy antes.

Essa etapa acontece direto entre você e a Pluggy — nem o site, nem eu, vemos sua senha do banco.

## 5. Atualizar o site depois de qualquer mudança

Sempre que eu (ou você) alterar algum arquivo do projeto, publique de novo com:

```bash
npx vercel --prod
```

## Como funciona por baixo dos panos

- As contas conectadas ficam guardadas no navegador (localStorage), não em um banco de dados —
  ou seja, é por navegador/computador. Se abrir em outro computador, terá que conectar de novo.
- Toda vez que você abre o painel, ele busca saldo e extrato direto na Pluggy (Inter, Sicredi, BB),
  sem guardar histórico no servidor.
- `api/connect-token.js`, `api/item.js`, `api/dashboard.js` e `api/delete-item.js` são funções
  que rodam na Vercel sob demanda (não ficam "ligadas" o tempo todo, e por isso não custam nada
  no plano gratuito).

## Limitações conhecidas

- Sem login/senha própria do site — qualquer pessoa com o link consegue ver o painel (mas só
  funciona se tiver as conexões salvas no navegador dela). Para uso só seu, isso é aceitável;
  se quiser adicionar uma senha simples de acesso, me avise.
- Módulo de investimentos (comparar CDI/Selic) não incluído neste recorte.
