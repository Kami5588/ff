// Camada de dados 100% local (localStorage). Sem backend, sem conta, sem custo.
// Espelha as entidades do app SmartFinance (base44): Transaction, Investment,
// Asset, CreditCard, FinancialGoal. Cada entidade é uma lista de objetos com "id".

const DB_PREFIX = "sf_db_";

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function loadList(entity) {
  try {
    return JSON.parse(localStorage.getItem(DB_PREFIX + entity) || "[]");
  } catch {
    return [];
  }
}
function saveList(entity, list) {
  localStorage.setItem(DB_PREFIX + entity, JSON.stringify(list));
}

const DB = {
  list(entity) {
    return loadList(entity);
  },
  get(entity, id) {
    return loadList(entity).find((r) => r.id === id) || null;
  },
  create(entity, record) {
    const list = loadList(entity);
    const withId = { ...record, id: uid(), created_date: new Date().toISOString() };
    list.push(withId);
    saveList(entity, list);
    return withId;
  },
  update(entity, id, patch) {
    const list = loadList(entity);
    const idx = list.findIndex((r) => r.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...patch };
    saveList(entity, list);
    return list[idx];
  },
  remove(entity, id) {
    const list = loadList(entity).filter((r) => r.id !== id);
    saveList(entity, list);
  },
  query(entity, predicate) {
    return loadList(entity).filter(predicate);
  },
};

// FinancialGoal é um "singleton" por ano — helper de conveniência.
function getGoal(year) {
  const goals = DB.list("FinancialGoal");
  let goal = goals.find((g) => g.year === year);
  if (!goal) {
    goal = DB.create("FinancialGoal", {
      year,
      annual_goal: 50000,
      initial_cash: 0,
      monthly_budget_expense: 0,
      currency_usd_amount: 0,
      currency_usd_rate: 5.0,
      cash_physical: 0,
    });
  }
  return goal;
}
function saveGoal(year, patch) {
  const goal = getGoal(year);
  return DB.update("FinancialGoal", goal.id, patch);
}

const MONTHS_PT = [
  "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
  "Jul", "Ago", "Set", "Out", "Nov", "Dez",
];

const EXPENSE_CATEGORIES = [
  "Alimentação", "Moradia", "Transporte", "Saúde", "Educação", "Lazer",
  "Fatura", "Assinaturas", "Compras", "Investimentos", "Outros",
];
const INCOME_CATEGORIES = ["Salário", "Freelance", "Investimentos", "Presente", "Outros"];
