import { pluggyFetch } from "../lib/pluggy.js";

async function fetchAccounts(itemId) {
  const json = await pluggyFetch(`/accounts?itemId=${encodeURIComponent(itemId)}`);
  return json.results || [];
}

async function fetchTransactions(accountId, dateFrom) {
  let all = [];
  let next = `/v2/transactions?accountId=${encodeURIComponent(accountId)}&dateFrom=${dateFrom}`;
  let guard = 0;
  while (next && guard < 10) {
    const json = await pluggyFetch(next);
    all = all.concat(json.results || []);
    next = json.next ? `/v2/transactions${json.next}` : null;
    guard++;
  }
  return all;
}

export async function POST(request) {
  try {
    const body = await request.json().catch(() => ({}));
    const connections = Array.isArray(body.connections) ? body.connections : [];
    const accounts = [];
    const transactions = [];
    const errors = [];

    const dateFrom = new Date();
    dateFrom.setDate(dateFrom.getDate() - 90);
    const dateFromStr = dateFrom.toISOString().slice(0, 10);

    for (const conn of connections) {
      try {
        const accs = await fetchAccounts(conn.itemId);
        for (const acc of accs) {
          accounts.push({
            id: acc.id,
            itemId: conn.itemId,
            bankName: conn.bankName,
            type: acc.type,
            subtype: acc.subtype,
            name: acc.name,
            number: acc.number,
            balance: acc.balance,
            currencyCode: acc.currencyCode,
          });
          try {
            const txs = await fetchTransactions(acc.id, dateFromStr);
            for (const t of txs) {
              transactions.push({
                id: t.id,
                accountId: acc.id,
                bankName: conn.bankName,
                description: t.description,
                amount: t.amount,
                type: t.type,
                category: t.category || "Outros",
                date: t.date,
                status: t.status,
              });
            }
          } catch (e) {
            errors.push(`Extrato de ${conn.bankName} (${acc.name}): ${e.message}`);
          }
        }
      } catch (e) {
        errors.push(`Contas de ${conn.bankName}: ${e.message}`);
      }
    }

    transactions.sort((a, b) => new Date(b.date) - new Date(a.date));
    const totalBalance = accounts
      .filter((a) => a.type === "BANK")
      .reduce((sum, a) => sum + (a.balance || 0), 0);
    const totalCreditUsed = accounts
      .filter((a) => a.type === "CREDIT")
      .reduce((sum, a) => sum + (a.balance || 0), 0);

    return Response.json({
      totalBalance,
      totalCreditUsed,
      accounts,
      transactions: transactions.slice(0, 100),
      errors,
    });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
