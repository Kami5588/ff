// Cotação de ações/FIIs via brapi.dev (API pública do mercado brasileiro).
// Sem token, funciona só para PETR4, VALE3, MGLU3, ITUB4 (sandbox).
// Com BRAPI_TOKEN configurado (gratuito em brapi.dev/dashboard), funciona pra qualquer ticker.

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const ticker = (url.searchParams.get("ticker") || "").trim().toUpperCase();
    if (!ticker) return Response.json({ error: "ticker é obrigatório" }, { status: 400 });

    const token = process.env.BRAPI_TOKEN;
    const brapiUrl = new URL("https://brapi.dev/api/v2/stocks/quote");
    brapiUrl.searchParams.set("symbols", ticker);

    const res = await fetch(brapiUrl.toString(), {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    const body = await res.json().catch(() => ({}));

    if (!res.ok || !body.results || !body.results.length || !body.results[0].data) {
      const msg =
        body?.message ||
        "Cotação não encontrada. Sem BRAPI_TOKEN configurado, só funciona para PETR4, VALE3, MGLU3 e ITUB4 — crie um token grátis em brapi.dev/dashboard e adicione BRAPI_TOKEN nas variáveis de ambiente da Vercel pra liberar qualquer ticker.";
      return Response.json({ error: msg }, { status: 404 });
    }

    const r = body.results[0];
    const d = r.data;
    return Response.json({
      ticker: r.symbol,
      name: d.longName || d.shortName || r.symbol,
      price: d.regularMarketPrice,
      changePercent: d.regularMarketChangePercent,
      currency: d.currency || "BRL",
      updatedAt: d.regularMarketTime || new Date().toISOString(),
    });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
