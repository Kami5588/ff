# SmartFinance (versão site completa — gratuita)

Site com o mesmo conjunto de telas do app SmartFinance: Visão Geral, Lançamentos, Orçamento
Mensal, Investimentos, Ativos × Passivos, Cartões & Dívidas, Gráficos, Importar Planilha e
Configurações — com integração real de banco (Pluggy/Open Finance) na aba Configurações.

## Publicar (sem terminal, via vercel.com/drop)

1. Arraste a pasta `smartfinance-web` (ou o zip) em **vercel.com/drop**.
2. Dê um nome ao projeto e clique em "Deploy".
3. No projeto criado, vá em **Settings → Environment Variables** e adicione:
   - `PLUGGY_CLIENT_ID` e `PLUGGY_CLIENT_SECRET` — chaves da sua Application em dashboard.pluggy.ai
     (veja o passo a passo em https://www.pluggy.ai/meu-pluggy).
   - `BRAPI_TOKEN` (opcional) — token grátis em https://brapi.dev/dashboard, libera cotação de
     qualquer ação/FII na aba Investimentos. Sem essa variável, só funcionam os tickers de teste
     PETR4, VALE3, MGLU3 e ITUB4.
4. Na aba **Deployments**, clique nos "..." do deploy mais recente → **Redeploy**, pra aplicar as
   variáveis.
5. Abra a URL do site.

## Como os dados são guardados

Tudo fica salvo no `localStorage` do seu navegador — não existe banco de dados nem conta de
usuário. Isso significa:

- Zero custo além do já mencionado (Vercel grátis, Pluggy grátis pra uso pessoal).
- Os dados ficam presos a um navegador/computador — abrir em outro aparelho começa do zero.
- Limpar os dados do navegador apaga os lançamentos. Vale exportar/fazer backup de vez em quando
  (posso adicionar um botão de exportar/importar backup se quiser).

## O que é real e o que é aproximado

- **Saldo, extrato, cartão de crédito**: dados reais, vindos da Pluggy (Open Finance) — mesma
  integração da versão anterior, agora dentro da aba Configurações.
- **Cotações de ações/FIIs**: dados reais da B3 via brapi.dev.
- **"Entrada Rápida" em Lançamentos**: não é IA de verdade — é um parser simples (captura valor
  numérico e chuta categoria por palavra-chave). Funciona para frases simples; para algo mais
  esperto exigiria uma chave de API de IA (posso integrar depois se você quiser).
- **Visão Geral, patrimônio, orçamento**: calculados a partir dos lançamentos manuais + dados da
  Pluggy + investimentos que você cadastrar — não há mágica, é soma dos dados que você tem no app.

## Limitações conhecidas

- Sem login/senha própria — qualquer pessoa com o link vê a tela, mas só enxerga dados se tiver
  esse mesmo navegador com as conexões salvas.
- Um único usuário por navegador (não é multiusuário).
- Módulo de investimentos não dá recomendação de onde investir (isso esbarra na regulação da CVM,
  como já conversamos) — só mostra e organiza o que você já tem.
