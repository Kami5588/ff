/* global DB, Chart, PluggyConnect */
"use strict";

/* ============================== Helpers ============================== */
const fmtMoney = (v) => (Number(v) || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString("pt-BR") : "");
const todayISO = () => new Date().toISOString().slice(0, 10);
const CURRENT_YEAR = new Date().getFullYear();
const TYPE_LABEL = {
  receita: "Receita", gasto: "Gasto", investimento: "Investimento",
  provento: "Provento", dividendo: "Dividendo", renda_passiva: "Renda passiva",
};

function el(id) { return document.getElementById(id); }
function fillSelect(select, options) {
  select.innerHTML = options.map((o) => `<option value="${o}">${o}</option>`).join("");
}

/* ============================== Navegação ============================== */
function initNav() {
  document.querySelectorAll(".nav-item[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".nav-item[data-page]").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".page").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      el("page-" + btn.dataset.page).classList.add("active");
      renderPage(btn.dataset.page);
    });
  });
  document.querySelectorAll(".tab-btn[data-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const group = btn.parentElement;
      group.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
      el("tab-" + btn.dataset.tab).classList.add("active");
    });
  });
}

function renderPage(page) {
  if (page === "visao-geral") renderVisaoGeral();
  if (page === "lancamentos") renderLancamentos();
  if (page === "orcamento") renderOrcamento();
  if (page === "investimentos") renderInvestimentos();
  if (page === "ativos-passivos") renderAtivosPassivos();
  if (page === "cartoes") renderCartoes();
  if (page === "graficos") renderGraficos();
  if (page === "configuracoes") renderConfiguracoes();
}

/* ============================== Saldo bancário (Pluggy) cache ============================== */
const BANK_CACHE_KEY = "sf_bank_balances";
function getBankBalances() {
  try { return JSON.parse(localStorage.getItem(BANK_CACHE_KEY) || "[]"); } catch { return []; }
}
function setBankBalances(list) { localStorage.setItem(BANK_CACHE_KEY, JSON.stringify(list)); }
function bankCashTotal() {
  return getBankBalances().filter((a) => a.type === "BANK").reduce((s, a) => s + (a.balance || 0), 0);
}
function bankCreditTotal() {
  return getBankBalances().filter((a) => a.type === "CREDIT").reduce((s, a) => s + (a.balance || 0), 0);
}

/* ============================== VISÃO GERAL ============================== */
function renderVisaoGeral() {
  el("vg-year").textContent = CURRENT_YEAR;
  const goal = getGoal(CURRENT_YEAR);
  const txs = DB.list("Transaction").filter((t) => new Date(t.date).getFullYear() === CURRENT_YEAR);

  const receitas = txs.filter((t) => t.type === "receita").reduce((s, t) => s + t.amount, 0);
  const gastos = txs.filter((t) => t.type === "gasto").reduce((s, t) => s + t.amount, 0);
  const proventos = txs
    .filter((t) => ["provento", "dividendo", "renda_passiva"].includes(t.type))
    .reduce((s, t) => s + t.amount, 0);
  const lucroLiquido = receitas - gastos;
  const investimentos = DB.list("Investment");
  const rendaPassivaMes = investimentos.reduce((s, i) => s + (Number(i.monthly_income) || 0), 0);

  const caixaBancos = bankCashTotal();
  const usdBRL = (goal.currency_usd_amount || 0) * (goal.currency_usd_rate || 0);
  const caixaAtual = caixaBancos + usdBRL + (goal.cash_physical || 0);

  el("vg-cards").innerHTML = `
    <div class="card">
      <div class="card-top"><span class="card-label">Faturamento atual</span><span class="card-icon" style="background:var(--green-soft)">↗</span></div>
      <div class="card-value">${fmtMoney(receitas)}</div>
      <div class="card-sub">Meta: ${fmtMoney(goal.annual_goal)}</div>
    </div>
    <div class="card">
      <div class="card-top"><span class="card-label">Caixa atual</span><span class="card-icon" style="background:var(--green-soft)">🏦</span></div>
      <div class="card-value">${fmtMoney(caixaAtual)}</div>
      <div class="card-sub">Bancos + dólar + espécie</div>
    </div>
    <div class="card">
      <div class="card-top"><span class="card-label">Lucro líquido</span><span class="card-icon" style="background:var(--green-soft)">$</span></div>
      <div class="card-value">${fmtMoney(lucroLiquido)}</div>
      <div class="card-sub">Jan–Dez ${CURRENT_YEAR}</div>
    </div>
    <div class="card">
      <div class="card-top"><span class="card-label">Renda passiva/mês</span><span class="card-icon" style="background:var(--purple-soft)">🐷</span></div>
      <div class="card-value">${fmtMoney(rendaPassivaMes)}</div>
      <div class="card-sub">FIIs + dividendos</div>
    </div>
  `;

  const pct = goal.annual_goal ? Math.min(100, (receitas / goal.annual_goal) * 100) : 0;
  el("vg-goal-fill").style.width = pct.toFixed(1) + "%";
  el("vg-goal-text").textContent =
    receitas >= goal.annual_goal
      ? `Meta atingida! ${pct.toFixed(1)}%`
      : `Faltam ${fmtMoney(goal.annual_goal - receitas)} para atingir ${fmtMoney(goal.annual_goal)} (${pct.toFixed(1)}%)`;

  el("vg-extra-cards").innerHTML = `
    <div class="card">
      <div class="card-top"><span class="card-label">Dólar físico</span><span class="card-icon" style="background:var(--blue-soft)">💵</span></div>
      <div class="card-value">US$ ${(goal.currency_usd_amount || 0).toLocaleString("pt-BR")}</div>
      <div class="card-sub">Cotação R$ ${(goal.currency_usd_rate || 0).toFixed(2)} = ${fmtMoney(usdBRL)}</div>
    </div>
    <div class="card">
      <div class="card-top"><span class="card-label">Dinheiro em espécie</span><span class="card-icon" style="background:var(--amber-soft)">💰</span></div>
      <div class="card-value">${fmtMoney(goal.cash_physical)}</div>
    </div>
  `;

  const assets = DB.list("Asset");
  const ativosManuais = assets.filter((a) => a.type === "ativo").reduce((s, a) => s + a.value, 0);
  const passivosManuais = assets.filter((a) => a.type === "passivo").reduce((s, a) => s + a.value, 0);
  const cards = DB.list("CreditCard").filter((c) => c.status !== "paga");
  const dividaCartoes = cards.reduce((s, c) => s + (c.total_amount || 0), 0);
  const valorCarteira = investimentos.reduce((s, i) => s + (i.shares || 0) * (i.current_price || i.avg_price || 0), 0);

  const ativosCirculantes = caixaAtual + valorCarteira;
  const ativosNaoCirculantes = ativosManuais;
  const passivosTotais = passivosManuais + dividaCartoes + bankCreditTotal();
  const patrimonioLiquido = ativosCirculantes + ativosNaoCirculantes - passivosTotais;

  el("vg-health-cards").innerHTML = `
    <div class="card"><span class="card-label">Ativos circulantes</span><div class="card-value" style="font-size:19px;">${fmtMoney(ativosCirculantes)}</div><div class="card-sub">Bancos + investimentos</div></div>
    <div class="card"><span class="card-label">Ativos não-circulantes</span><div class="card-value" style="font-size:19px;">${fmtMoney(ativosNaoCirculantes)}</div><div class="card-sub">Bens e imóveis</div></div>
    <div class="card"><span class="card-label">Passivos totais</span><div class="card-value negative" style="font-size:19px;">${passivosTotais ? "-" + fmtMoney(passivosTotais) : "—"}</div><div class="card-sub">Dívidas e obrigações</div></div>
    <div class="card"><span class="card-label">Patrimônio líquido</span><div class="card-value" style="font-size:19px;">${fmtMoney(patrimonioLiquido)}</div><div class="card-sub">Circ. + N.Circ. − Passivos</div></div>
  `;

  const byMonth = Array(12).fill(0);
  txs.filter((t) => t.type === "receita").forEach((t) => { byMonth[new Date(t.date).getMonth()] += t.amount; });
  drawBarChart("vg-month-chart", MONTHS_PT, [{ label: "Faturamento", data: byMonth, color: "#2f5233" }]);
}

/* ============================== LANÇAMENTOS ============================== */
function txCategoriesFor(type) {
  return ["receita", "provento", "dividendo", "renda_passiva"].includes(type) ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
}
function initLancamentosForm() {
  el("tx-date").value = todayISO();
  fillSelect(el("tx-category"), txCategoriesFor(el("tx-type").value));
  el("tx-type").addEventListener("change", () => fillSelect(el("tx-category"), txCategoriesFor(el("tx-type").value)));

  el("tx-add-btn").addEventListener("click", () => {
    const amount = parseFloat(el("tx-amount").value);
    const description = el("tx-desc").value.trim();
    if (!description || !amount) { alert("Preencha descrição e valor."); return; }
    DB.create("Transaction", {
      date: el("tx-date").value || todayISO(),
      description,
      amount: Math.abs(amount),
      type: el("tx-type").value,
      category: el("tx-category").value,
      source: "manual",
    });
    el("tx-desc").value = "";
    el("tx-amount").value = "";
    renderLancamentos();
    if (document.querySelector('.nav-item[data-page="visao-geral"]').classList.contains("active")) renderVisaoGeral();
  });

  el("quick-entry-btn").addEventListener("click", quickEntryParse);
  el("quick-entry-input").addEventListener("keydown", (e) => { if (e.key === "Enter") quickEntryParse(); });

  el("tx-filter").addEventListener("change", renderLancamentos);
}

function quickEntryParse() {
  const text = el("quick-entry-input").value.trim();
  if (!text) return;
  const lower = text.toLowerCase();
  const amountMatch = text.match(/(\d+(?:[.,]\d{1,2})?)/);
  const amount = amountMatch ? parseFloat(amountMatch[1].replace(",", ".")) : null;
  const isIncome = /(recebi|receita|entrada|ganhei|caiu)/.test(lower);
  const type = isIncome ? "receita" : "gasto";

  let category = "Outros";
  const keywordMap = {
    Alimentação: ["mercado", "restaurante", "ifood", "supermercado", "padaria", "lanche"],
    Transporte: ["uber", "gasolina", "combustível", "ônibus", "99"],
    Moradia: ["aluguel", "condomínio", "luz", "água", "internet"],
    Saúde: ["farmácia", "remédio", "médico", "plano de saúde"],
    Lazer: ["cinema", "show", "viagem", "bar"],
    Salário: ["salário", "salario"],
    Freelance: ["freela", "projeto", "cliente"],
  };
  for (const [cat, words] of Object.entries(keywordMap)) {
    if (words.some((w) => lower.includes(w))) { category = cat; break; }
  }
  const description = text.replace(/(\d+(?:[.,]\d{1,2})?)/, "").replace(/reais|r\$/gi, "").trim() || text;

  el("tx-date").value = todayISO();
  el("tx-desc").value = description.charAt(0).toUpperCase() + description.slice(1);
  el("tx-amount").value = amount || "";
  el("tx-type").value = type;
  fillSelect(el("tx-category"), txCategoriesFor(type));
  el("tx-category").value = category;
  el("quick-entry-input").value = "";
}

function renderLancamentos() {
  const filter = el("tx-filter").value;
  let txs = DB.list("Transaction").sort((a, b) => new Date(b.date) - new Date(a.date));
  if (filter !== "todos") txs = txs.filter((t) => t.type === filter);
  el("tx-count").textContent = `${txs.length} transações`;

  const tbody = el("tx-list-body");
  if (!txs.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="empty">Nenhum lançamento ainda.</td></tr>`;
    return;
  }
  tbody.innerHTML = txs
    .map(
      (t) => `
    <tr>
      <td>${fmtDate(t.date)}</td>
      <td>${t.description}</td>
      <td><span class="badge badge-${t.type}">${TYPE_LABEL[t.type] || t.type}</span></td>
      <td>${t.category || "—"}</td>
      <td class="right ${t.type === "gasto" ? "amount-negative" : "amount-positive"}">${t.type === "gasto" ? "- " : "+ "}${fmtMoney(t.amount)}</td>
      <td><button class="btn-icon" data-del="${t.id}">🗑</button></td>
    </tr>`
    )
    .join("");
  tbody.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => { DB.remove("Transaction", btn.dataset.del); renderLancamentos(); })
  );
}

/* ============================== ORÇAMENTO MENSAL ============================== */
function initOrcamentoForm() {
  fillSelect(el("budget-category"), EXPENSE_CATEGORIES);
  el("budget-add-btn").addEventListener("click", () => {
    const category = el("budget-category").value;
    const amount = parseFloat(el("budget-amount").value);
    if (!amount) return;
    const existing = DB.list("Budget").find((b) => b.category === category);
    if (existing) DB.update("Budget", existing.id, { amount });
    else DB.create("Budget", { category, amount });
    el("budget-amount").value = "";
    renderOrcamento();
  });
}
function renderOrcamento() {
  const budgets = DB.list("Budget");
  const now = new Date();
  const txsThisMonth = DB.list("Transaction").filter((t) => {
    const d = new Date(t.date);
    return t.type === "gasto" && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });
  const spentByCategory = {};
  txsThisMonth.forEach((t) => { spentByCategory[t.category] = (spentByCategory[t.category] || 0) + t.amount; });

  const el2 = el("budget-list");
  const categories = Array.from(new Set([...budgets.map((b) => b.category), ...Object.keys(spentByCategory)]));
  if (!categories.length) {
    el2.innerHTML = '<div class="empty">Defina um orçamento por categoria acima pra começar.</div>';
    return;
  }
  el2.innerHTML = categories
    .map((cat) => {
      const budget = budgets.find((b) => b.category === cat);
      const spent = spentByCategory[cat] || 0;
      const limit = budget ? budget.amount : 0;
      const pct = limit ? Math.min(100, (spent / limit) * 100) : 0;
      const over = limit && spent > limit;
      return `
      <div class="list-item" style="flex-direction:column; align-items:stretch; gap:6px;">
        <div style="display:flex; justify-content:space-between;">
          <span class="meta name">${cat}</span>
          <span class="${over ? "amount-negative" : ""}">${fmtMoney(spent)} ${limit ? "/ " + fmtMoney(limit) : "(sem orçamento definido)"}</span>
        </div>
        ${limit ? `<div class="progress-track"><div class="progress-fill" style="width:${pct}%; background:${over ? "var(--red)" : "var(--accent)"}"></div></div>` : ""}
      </div>`;
    })
    .join("");
}

/* ============================== INVESTIMENTOS ============================== */
function initInvestimentosForm() {
  el("inv-add-btn").addEventListener("click", () => {
    const ticker = el("inv-ticker").value.trim().toUpperCase();
    if (!ticker) return;
    DB.create("Investment", {
      ticker,
      type: el("inv-type").value,
      shares: parseFloat(el("inv-shares").value) || 0,
      avg_price: parseFloat(el("inv-avgprice").value) || 0,
      current_price: 0,
      monthly_income: parseFloat(el("inv-income").value) || 0,
    });
    el("inv-ticker").value = "";
    el("inv-shares").value = "";
    el("inv-avgprice").value = "";
    el("inv-income").value = "";
    renderInvestimentos();
  });
  el("inv-refresh-btn").addEventListener("click", refreshQuotes);
  el("b3-search-btn").addEventListener("click", searchB3);
  el("b3-search-input").addEventListener("keydown", (e) => { if (e.key === "Enter") searchB3(); });
}

async function fetchQuote(ticker) {
  const res = await fetch(`/api/quote?ticker=${encodeURIComponent(ticker)}`);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || "Falha ao buscar cotação");
  return json;
}

async function refreshQuotes() {
  const list = DB.list("Investment");
  const btn = el("inv-refresh-btn");
  btn.disabled = true;
  btn.textContent = "Atualizando...";
  for (const inv of list) {
    try {
      const q = await fetchQuote(inv.ticker);
      DB.update("Investment", inv.id, { current_price: q.price });
    } catch (e) {
      console.warn("Cotação falhou para", inv.ticker, e.message);
    }
  }
  btn.disabled = false;
  btn.textContent = "↻ Atualizar cotações";
  renderInvestimentos();
}

async function searchB3() {
  const ticker = el("b3-search-input").value.trim().toUpperCase();
  if (!ticker) return;
  const box = el("b3-search-result");
  box.innerHTML = '<div class="empty">Buscando...</div>';
  try {
    const q = await fetchQuote(ticker);
    const changeColor = q.changePercent >= 0 ? "amount-positive" : "amount-negative";
    box.innerHTML = `
      <div class="card" style="max-width:320px;">
        <div class="card-label">${q.name}</div>
        <div class="card-value">${fmtMoney(q.price)}</div>
        <div class="${changeColor}">${q.changePercent >= 0 ? "+" : ""}${(q.changePercent || 0).toFixed(2)}%</div>
      </div>`;
  } catch (e) {
    box.innerHTML = `<div class="banner">${e.message}</div>`;
  }
}

function renderInvestimentos() {
  const list = DB.list("Investment");
  const totalInvestido = list.reduce((s, i) => s + i.shares * i.avg_price, 0);
  const rendaMensal = list.reduce((s, i) => s + (Number(i.monthly_income) || 0), 0);
  const proventos = DB.list("Transaction").filter((t) => ["provento", "dividendo"].includes(t.type));
  const totalProventos = proventos.reduce((s, t) => s + t.amount, 0);

  el("inv-cards").innerHTML = `
    <div class="card"><span class="card-label">Total investido (PM)</span><div class="card-value">${fmtMoney(totalInvestido)}</div></div>
    <div class="card"><span class="card-label">Proventos recebidos</span><div class="card-value">${fmtMoney(totalProventos)}</div></div>
    <div class="card"><span class="card-label">Renda passiva/mês</span><div class="card-value">${fmtMoney(rendaMensal)}</div></div>
  `;

  const tbody = el("inv-list-body");
  if (!list.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="empty">Nenhum ativo na carteira ainda.</td></tr>`;
  } else {
    tbody.innerHTML = list
      .map((i) => {
        const price = i.current_price || i.avg_price;
        const total = i.shares * price;
        return `
        <tr>
          <td><strong>${i.ticker}</strong></td>
          <td>${i.type}</td>
          <td>${i.shares}</td>
          <td class="right">${fmtMoney(i.avg_price)}</td>
          <td class="right">${i.current_price ? fmtMoney(i.current_price) : "—"}</td>
          <td class="right">${fmtMoney(total)}</td>
          <td class="right amount-positive">${fmtMoney(i.monthly_income)}</td>
          <td><button class="btn-icon" data-del="${i.id}">🗑</button></td>
        </tr>`;
      })
      .join("");
    tbody.querySelectorAll("[data-del]").forEach((btn) =>
      btn.addEventListener("click", () => { DB.remove("Investment", btn.dataset.del); renderInvestimentos(); })
    );
  }

  const provBody = el("proventos-list");
  provBody.innerHTML = proventos.length
    ? proventos
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .map((p) => `<div class="list-item"><div class="meta"><span class="name">${p.description}</span><span class="sub">${fmtDate(p.date)}</span></div><span class="amount-positive">+ ${fmtMoney(p.amount)}</span></div>`)
        .join("")
    : '<div class="empty">Nenhum provento lançado ainda.</div>';
}

/* ============================== ATIVOS x PASSIVOS ============================== */
function initAssetForm() {
  el("asset-add-btn").addEventListener("click", () => {
    const description = el("asset-desc").value.trim();
    const value = parseFloat(el("asset-value").value);
    if (!description || !value) return;
    DB.create("Asset", { description, value, type: el("asset-type").value, category: el("asset-category").value || "Outros" });
    el("asset-desc").value = "";
    el("asset-value").value = "";
    el("asset-category").value = "";
    renderAtivosPassivos();
  });
}
function renderAtivosPassivos() {
  const list = DB.list("Asset").sort((a, b) => (b.created_date || "").localeCompare(a.created_date || ""));
  const tbody = el("asset-list-body");
  tbody.innerHTML = list.length
    ? list
        .map(
          (a) => `
      <tr>
        <td>${a.description}</td>
        <td>${a.category || "—"}</td>
        <td><span class="badge ${a.type === "ativo" ? "badge-receita" : "badge-gasto"}">${a.type}</span></td>
        <td class="right">${fmtMoney(a.value)}</td>
        <td><button class="btn-icon" data-del="${a.id}">🗑</button></td>
      </tr>`
        )
        .join("")
    : `<tr><td colspan="5" class="empty">Nada cadastrado ainda.</td></tr>`;
  tbody.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => { DB.remove("Asset", btn.dataset.del); renderAtivosPassivos(); })
  );
}

/* ============================== CARTÕES & DÍVIDAS ============================== */
function initCardForm() {
  el("card-add-btn").addEventListener("click", () => {
    const card_name = el("card-name").value.trim();
    const description = el("card-desc").value.trim();
    const total_amount = parseFloat(el("card-amount").value);
    const installments_total = parseInt(el("card-installments").value, 10) || 1;
    const due_date = el("card-due").value || todayISO();
    if (!card_name || !description || !total_amount) return;
    DB.create("CreditCard", {
      card_name, description, total_amount, installments_total,
      installments_paid: 0,
      installment_value: total_amount / installments_total,
      due_date, category: "Outros", status: "aberta",
    });
    el("card-name").value = "";
    el("card-desc").value = "";
    el("card-amount").value = "";
    el("card-installments").value = "1";
    renderCartoes();
  });
}
function renderCartoes() {
  const list = DB.list("CreditCard").sort((a, b) => (a.due_date || "").localeCompare(b.due_date || ""));
  const tbody = el("card-list-body");
  tbody.innerHTML = list.length
    ? list
        .map(
          (c) => `
      <tr>
        <td>${c.card_name}</td>
        <td>${c.description}</td>
        <td>${c.installments_paid}/${c.installments_total}</td>
        <td>${fmtDate(c.due_date)}</td>
        <td><span class="badge ${c.status === "paga" ? "badge-receita" : c.status === "vencida" ? "badge-gasto" : "badge-investimento"}">${c.status}</span></td>
        <td class="right">${fmtMoney(c.total_amount)}</td>
        <td>
          ${c.status !== "paga" ? `<button class="btn-icon" data-pay="${c.id}" title="Marcar como paga">✔</button>` : ""}
          <button class="btn-icon" data-del="${c.id}">🗑</button>
        </td>
      </tr>`
        )
        .join("")
    : `<tr><td colspan="7" class="empty">Nenhuma fatura ou dívida cadastrada.</td></tr>`;
  tbody.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => { DB.remove("CreditCard", btn.dataset.del); renderCartoes(); })
  );
  tbody.querySelectorAll("[data-pay]").forEach((btn) =>
    btn.addEventListener("click", () => { DB.update("CreditCard", btn.dataset.pay, { status: "paga" }); renderCartoes(); })
  );
}

/* ============================== GRÁFICOS ============================== */
const chartInstances = {};
function drawBarChart(canvasId, labels, datasets) {
  const ctx = el(canvasId);
  if (!ctx) return;
  if (chartInstances[canvasId]) chartInstances[canvasId].destroy();
  chartInstances[canvasId] = new Chart(ctx, {
    type: "bar",
    data: { labels, datasets: datasets.map((d) => ({ label: d.label, data: d.data, backgroundColor: d.color })) },
    options: { plugins: { legend: { display: datasets.length > 1 } }, scales: { y: { beginAtZero: true } } },
  });
}
function drawDoughnut(canvasId, labels, data) {
  const ctx = el(canvasId);
  if (!ctx) return;
  if (chartInstances[canvasId]) chartInstances[canvasId].destroy();
  if (!labels.length) return;
  chartInstances[canvasId] = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels,
      datasets: [{ data, backgroundColor: ["#2f5233", "#c0392b", "#3f6b45", "#8a8579", "#7c5cbf", "#c98a2b", "#2b7ca6", "#a63d5a", "#5a8a3d", "#3d5a8a"] }],
    },
    options: { plugins: { legend: { position: "right" } } },
  });
}

function renderGraficos() {
  const txs = DB.list("Transaction").filter((t) => new Date(t.date).getFullYear() === CURRENT_YEAR);
  const receitasByMonth = Array(12).fill(0);
  const gastosByMonth = Array(12).fill(0);
  txs.forEach((t) => {
    const m = new Date(t.date).getMonth();
    if (t.type === "receita") receitasByMonth[m] += t.amount;
    if (t.type === "gasto") gastosByMonth[m] += t.amount;
  });
  drawBarChart("chart-in-out", MONTHS_PT, [
    { label: "Entradas", data: receitasByMonth, color: "#2f5233" },
    { label: "Saídas", data: gastosByMonth, color: "#c0392b" },
  ]);

  const byCategory = {};
  txs.filter((t) => t.type === "gasto").forEach((t) => { byCategory[t.category] = (byCategory[t.category] || 0) + t.amount; });
  drawDoughnut("chart-category", Object.keys(byCategory), Object.values(byCategory));

  const assets = DB.list("Asset");
  const invest = DB.list("Investment").reduce((s, i) => s + i.shares * (i.current_price || i.avg_price), 0);
  const caixa = bankCashTotal();
  const patrimonioLabels = ["Caixa/Bancos", "Investimentos", "Ativos manuais", "Passivos"];
  const patrimonioData = [
    caixa,
    invest,
    assets.filter((a) => a.type === "ativo").reduce((s, a) => s + a.value, 0),
    assets.filter((a) => a.type === "passivo").reduce((s, a) => s + a.value, 0),
  ];
  drawDoughnut("chart-patrimonio", patrimonioLabels, patrimonioData);
}

/* ============================== IMPORTAR PLANILHA ============================== */
function initImportForm() {
  el("import-file").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result);
      const lines = text.split(/\r?\n/).filter((l) => l.trim());
      let count = 0;
      lines.forEach((line, idx) => {
        if (idx === 0 && /data|descri/i.test(line)) return; // pula cabeçalho
        const [date, description, amountStr, type, category] = line.split(",").map((s) => (s || "").trim());
        const amount = parseFloat((amountStr || "0").replace(",", "."));
        if (!date || !description || !amount) return;
        DB.create("Transaction", {
          date, description, amount: Math.abs(amount),
          type: type || (amount < 0 ? "gasto" : "receita"),
          category: category || "Outros",
          source: "import",
        });
        count++;
      });
      el("import-result").textContent = `${count} lançamentos importados.`;
      renderLancamentos();
    };
    reader.readAsText(file);
  });
}

/* ============================== CONFIGURAÇÕES ============================== */
function initConfigForm() {
  el("cfg-save-btn").addEventListener("click", () => {
    saveGoal(CURRENT_YEAR, {
      annual_goal: parseFloat(el("cfg-goal").value) || 0,
      monthly_budget_expense: parseFloat(el("cfg-budget").value) || 0,
      currency_usd_amount: parseFloat(el("cfg-usd").value) || 0,
      currency_usd_rate: parseFloat(el("cfg-usd-rate").value) || 5.0,
      cash_physical: parseFloat(el("cfg-cash").value) || 0,
    });
    alert("Salvo!");
  });
}
function renderConfiguracoes() {
  const goal = getGoal(CURRENT_YEAR);
  el("cfg-goal").value = goal.annual_goal || "";
  el("cfg-budget").value = goal.monthly_budget_expense || "";
  el("cfg-usd").value = goal.currency_usd_amount || "";
  el("cfg-usd-rate").value = goal.currency_usd_rate || "";
  el("cfg-cash").value = goal.cash_physical || "";
}

/* ============================== PLUGGY (Open Finance) ============================== */
const CONN_STORAGE_KEY = "sf_connections";
function getConnections() {
  try { return JSON.parse(localStorage.getItem(CONN_STORAGE_KEY) || "[]"); } catch { return []; }
}
function saveConnections(list) { localStorage.setItem(CONN_STORAGE_KEY, JSON.stringify(list)); }

async function apiCall(pathname, options) {
  const res = await fetch(pathname, options);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `Erro ${res.status}`);
  return json;
}

function showPluggyWarning(msg) {
  const box = el("setup-warning");
  box.textContent = msg;
  box.classList.remove("hidden");
}
function clearPluggyWarning() {
  el("setup-warning").classList.add("hidden");
}

async function connectBank() {
  let tokenResp;
  try {
    tokenResp = await apiCall("/api/connect-token");
  } catch (e) {
    showPluggyWarning("Não foi possível gerar o token de conexão. Configure PLUGGY_CLIENT_ID e PLUGGY_CLIENT_SECRET nas variáveis de ambiente da Vercel. Detalhe: " + e.message);
    return;
  }
  const pluggyConnect = new PluggyConnect({
    connectToken: tokenResp.accessToken,
    includeSandbox: false,
    onSuccess: async (itemData) => {
      const itemId = itemData.item.id;
      let info = { itemId, bankName: "Banco", status: itemData.item.status };
      try { info = await apiCall(`/api/item?itemId=${encodeURIComponent(itemId)}`); } catch (e) { console.error(e); }
      const list = getConnections();
      const idx = list.findIndex((c) => c.itemId === itemId);
      const entry = { itemId, bankName: info.bankName, status: info.status, updatedAt: new Date().toISOString() };
      if (idx === -1) list.push(entry); else list[idx] = entry;
      saveConnections(list);
      loadPluggyDashboard();
    },
    onError: (error) => console.error("Erro no Pluggy Connect:", error),
  });
  pluggyConnect.init();
}

async function removeConnection(itemId) {
  if (!confirm("Remover esta conexão bancária?")) return;
  try { await apiCall(`/api/delete-item?itemId=${encodeURIComponent(itemId)}`, { method: "DELETE" }); } catch (e) { console.error(e); }
  saveConnections(getConnections().filter((c) => c.itemId !== itemId));
  loadPluggyDashboard();
}

function renderPluggyAccounts(accounts) {
  const box = el("accounts-list");
  box.innerHTML = accounts.length
    ? accounts.map((a) => `
      <div class="list-item">
        <div class="meta"><span class="name">${a.bankName} · ${a.name}</span><span class="sub">${a.number || ""}</span></div>
        <span class="${a.type === "CREDIT" ? "amount-negative" : ""}">${fmtMoney(a.balance)}</span>
      </div>`).join("")
    : '<div class="empty">Nenhuma conta conectada ainda.</div>';
}
function renderPluggyConnections(connections) {
  el("total-banks").textContent = connections.length;
  const box = el("connections-list");
  box.innerHTML = connections.length
    ? connections.map((c) => `
      <div class="list-item">
        <div class="meta"><span class="name">${c.bankName}</span><span class="sub">Status: ${c.status || "—"} · ${fmtDate(c.updatedAt)}</span></div>
        <button class="btn-ghost btn-sm" data-remove="${c.itemId}">Remover</button>
      </div>`).join("")
    : '<div class="empty">Nenhum banco conectado.</div>';
  box.querySelectorAll("[data-remove]").forEach((btn) => btn.addEventListener("click", () => removeConnection(btn.dataset.remove)));
}

function syncPluggyTransactionsIntoDB(transactions) {
  const existingIds = new Set(DB.list("Transaction").map((t) => t.external_id).filter(Boolean));
  let added = 0;
  for (const t of transactions) {
    if (existingIds.has(t.id)) continue;
    DB.create("Transaction", {
      date: (t.date || "").slice(0, 10),
      description: t.description,
      amount: Math.abs(t.amount),
      type: t.type === "CREDIT" ? "receita" : "gasto",
      category: t.category || "Outros",
      bank: t.bankName,
      source: "import",
      external_id: t.id,
    });
    existingIds.add(t.id);
    added++;
  }
  return added;
}

async function loadPluggyDashboard() {
  clearPluggyWarning();
  const connections = getConnections();
  renderPluggyConnections(connections);

  if (!connections.length) {
    el("total-balance").textContent = fmtMoney(0);
    el("total-credit").textContent = fmtMoney(0);
    renderPluggyAccounts([]);
    setBankBalances([]);
    return;
  }

  let data;
  try {
    data = await apiCall("/api/dashboard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ connections }),
    });
  } catch (e) {
    showPluggyWarning("Erro ao carregar o painel: " + e.message);
    return;
  }

  el("total-balance").textContent = fmtMoney(data.totalBalance);
  el("total-credit").textContent = fmtMoney(data.totalCreditUsed);
  renderPluggyAccounts(data.accounts);
  setBankBalances(data.accounts);

  const added = syncPluggyTransactionsIntoDB(data.transactions);
  if (added > 0 && document.querySelector('.nav-item[data-page="lancamentos"]').classList.contains("active")) {
    renderLancamentos();
  }

  if (data.errors && data.errors.length) showPluggyWarning(data.errors.join(" | "));
}

/* ============================== INIT ============================== */
document.addEventListener("DOMContentLoaded", () => {
  initNav();
  initLancamentosForm();
  initOrcamentoForm();
  initInvestimentosForm();
  initAssetForm();
  initCardForm();
  initImportForm();
  initConfigForm();
  el("btn-connect").addEventListener("click", connectBank);

  renderVisaoGeral();
  loadPluggyDashboard();
});
